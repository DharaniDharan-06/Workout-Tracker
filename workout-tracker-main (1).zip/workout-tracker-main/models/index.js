// Export Workout model
module.exports = {
    Workout: require("./Workout")
};